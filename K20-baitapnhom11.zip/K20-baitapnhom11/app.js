const express = require('express'); 
const app = express(); 
const path = require("path")

const cookieParser = require('cookie-parser') 

const UserRouter = require('./router/RouterUser')
const ListRouter = require('./router/listRouter')
const TodoRouter = require('./router/todoRouter')

app.use(cookieParser())
app.set('view engine','ejs')

app.use(express.urlencoded({extended: true})) 
app.use(express.json()) 

app.use('/user', UserRouter)
app.use('/list', ListRouter)
app.use('/todo', TodoRouter)

app.use('/public', express.static(path.join(__dirname, './public')));

const multer = require('multer')

const storage = multer.diskStorage({ 
    destination: function (req, file, cb) { 
      cb(null, 'public/uploads/') 
    },
    filename: function (req, file, cb) { 
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      console.log(20, path.extname(file.originalname)); 
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname)) 
    }
  })
  
const upload = multer({ storage: storage })


app.get('/home', function(req,res){
    res.render('page/home.ejs')
    console.log(1111);
})



app.listen(3000);