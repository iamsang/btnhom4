const UserModel = require('./models/UserModel')
var jwt = require('jsonwebtoken');

async function checkUser (req, res, next) {
    try {
        console.log(52, req.cookies.user);
        if (req.cookies.user) { // kiểm tra cookie
            const user = await UserModel.findOne({token: req.cookies.user})
            console.log(56, user._id);
            req.id = user._id // truyền id qua req khi kiểm tra checkLogin
            next()
        }else{
            res.redirect('/user/home') 
        }
    } catch (error) {
        res.redirect('/user/home')
    }
}

module.exports =  checkUser