$('.hide-dangxuat').click(function(){
  dangxuat() 
})
function dangxuat(){
  $.ajax({
      url: '/user/logout', 
      type: 'PUT',
  })
  .then(function(data){
      console.log(69, data);
      document.cookie = "user = ; expires=Thu, 18 Dec 2018 12:00:00 UTC; path=/";
      $('.thongbao').html(data.mess)
      window.location.href = '/user/home'
  })
  .catch(function(err){
      console.log(err);
      alert('khong ton tai cookie')
  })
}

async function add() {
  let name = $("#name").val();
  let status = $("#status").val();
  let deadline = $("#deadline").val();
  console.log(name, status, deadline);
  
  if (name && status && deadline) {
    try {
      const res = await $.ajax({
        url: "/todo",
        type: "POST",
        data: { name, status, deadline },
      });
      alert(res.mess)
      window.location.reload();
    } catch (error) {
      console.log(error);
    }
  } else {
    alert("hay dien du thong tin");
  }
}

async function xoatodo(id) {
  try {
    const res = await $.ajax({
      url: "/todo/" + id,
      type: "DELETE",
    });
    window.location.reload();
    console.log(31);
  } catch (error) {
    console.log(error);
  }
}


async function hiendatacu(id) {
  try {
    const res = await $.ajax({
      url: "/todo/" + id,
      type: "get",
    });
    $(`#name${id}`).val(res.todotest.name);
    $(`#status${id}`).val(res.todotest.status);
    $(`#deadline${id}`).val(res.todotest.deadline);
  } catch (error) {
    console.log(error);
  }
}

async function updatetodo(id) {
  let name = $(`#name${id}`).val();
  let status = $(`#status${id}`).val();
  let deadline = $(`#deadline${id}`).val();
  console.log(name, status, deadline);
  if (name&& status && deadline) {
    try {
      const res = await $.ajax({
        url: "/todo/"+id,
        type: "PUT",
        data: { name, status, deadline },
      });
      console.log(20,res);
      window.location.reload();
    } catch (error) {
      console.log(error);
    }
  } else {
    alert("hay dien du thong tin");
  }
}

async function sangtrang(status,page) {
    try { 
      console.log(74,page,status);
      const res = await $.ajax({
        url: `/todo/${status}/${page}`,
        type: "get",
      });
      // $(`.${status}`).html(code)
      // $('.todo').html(res)
      
      console.log(84,res)
      console.log(85,res[2 * (page - 1)].name,res[2 * (page - 1) + 1] .name)

    } catch (error) {
      console.log(error);
    }
 
}
async function addUser (){
  const username = $('#username').val()
  const password = $('#password').val()
  console.log(username, password);
  try {
    const res = await $.ajax({
      url:'/user/create',
      type:'POST',
      data: {username: username, password:password}
    })
    $('.listData').html('')
    $('.listData').html(res)
    // window.location.reload()
  } catch (error) {
    console.log(13, error);
  }
}
