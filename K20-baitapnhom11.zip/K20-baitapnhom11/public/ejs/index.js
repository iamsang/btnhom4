$('.hide-dangky').click(function(){
    $('.dangky').show()
    $('.dangnhap').hide()
    $('.TC').hide()
})
$('.hide-dangnhap').click(function(){
    $('.dangky').hide()
    $('.dangnhap').show()
    $('.TC').hide()
})

$('.hide-dangxuat').click(function(){
    dangxuat() 
})
$('.show-password').click(function(){
    $('.hide-password').show()
    $('.hide-avatar').hide()
})
$('.show-avatar').click(function(){
    $('.hide-avatar').show()
    $('.hide-password').hide()
})


async function dangky(){ // tạo username password
    try {
        const form = $('#form')[0]
        // dùng form để bắt nội dung trong input thì phái có class name trong html vd : name="password"
        const dataForm = new FormData(form) // bắt nội dụng nhập trong form bằng Formdata
        for(var pair of dataForm.entries()){
            console.log(14, pair[0], pair[1]);
        }
        
        const avatar = await $.ajax({
        url: '/user/profile', 
        type: 'POST',
        data: dataForm,
        contentType: false, // ajax để giữ nguyên kiểu dữ liệu formdata
        processData: false  // ajax để giữ nguyên kiểu dữ liệu formdata
        })
        console.log(24, avatar);
        $('.thongbao').html(avatar.mess)
    } catch (error) {
        console.log(27, error);
    }
}

async function dangnhap(){
    try {
        const username = $('#user-dangnhap').val()
        const password = $('#pass-dangnhap').val()
        console.log(35, username, password);
        const res = await $.ajax({
            url: '/user/login', 
            type: 'POST',
            data:{username : username, password: password}
        })
        console.log(41, res);
        console.log(42, res.user._id);
        console.log(43, document.cookie);
        $('.thongbao').html(res.mess)
        if (res.user._id) { // nếu id tồn tại trong database thì ép vào cookie
            window.location.href = '/user/list' 
        }
    } catch (error) {
        console.log(error);
        alert('sai user, passs')
    }
}

function dangxuat(){
    $.ajax({
        url: '/user/logout', 
        type: 'PUT',
    })
    .then(function(data){
        console.log(69, data);
        document.cookie = "user = ; expires=Thu, 18 Dec 2018 12:00:00 UTC; path=/";
        $('.thongbao').html(data.mess)
        window.location.href = '/user/home'
    })
    .catch(function(err){
        console.log(err);
        alert('khong ton tai cookie')
    })
}
async function Addlist(){
    try {
        const listName = $('#addList').val()
        if (listName === '') {
            alert('Vui lòng điền thông tin List Name')
        } else {
            console.log(79, listName);
            const res = await $.ajax({
                url: '/user/createList', 
                type: 'POST',
                data:{ListName : listName }
            })
            if(res.mess === 'List đã tồn tại'){
                alert('List đã tồn tại')
            }else{
                alert('tạo list OK')
                $('.list').html(res)
            }
        }
        $('#addList').val('')
    } catch (error) {
        console.log(error);
        alert('Lỗi sever')
        res.redirect('/user/home')
    } 
}

async function delList(id){
    try {
        const res = await $.ajax({
            url: '/user/delList/'+ id,
            type: 'DELETE'
        })
        $('.list').html(res)
    } catch (error) {
        console.log(error);
    }
}

async function upList(id){
    try {
        const newListname = $(`#listname${id}`).val()
        console.log(130,newListname);
        if (newListname === '') {
            alert('Chưa nhập tên ListName muốn thay đổi !')
        } else {
            const res = await $.ajax({
                url: '/user/upList/'+ id,
                type: 'PUT',
                data: {ListName: newListname}
            })
            if(res.mess === 'ListName đã tồn tại !'){
                alert('ListName đã tồn tại !')
            }else{
                alert('Thay đổi Listname thành công!')
                $('.clo').trigger('click')
                $('.list').html(res)
            }
        }
    } catch (error) {
        console.log(error);
    }
}

async function changeAvatar(){
    try {
        const form = $('#formuser')[0]
        console.log(146,form);
        const dataForm = new FormData(form) // bắt nội dụng nhập trong form bằng Formdata
        for(var pair of dataForm.entries()){
            console.log(148, pair[1]);
        }

        const avatar = await $.ajax({
            url: '/user/changeAvatar', 
            type: 'PUT',
            data: dataForm,
            contentType: false, // ajax để giữ nguyên kiểu dữ liệu formdata
            processData: false  // ajax để giữ nguyên kiểu dữ liệu formdata
        })
        console.log(159999, avatar);
        alert(avatar.mess)
        window.location.reload()
    } catch (error) {
        console.log(error);
    }
}
async function changePassword(){
    const pscu = $('#pscu').val()
    const psnew = $('#psnew').val()
    const psconfirm = $('#psconfirm').val()
    console.log(pscu);

    await $.ajax({
        url: '/user/changePassword', 
        type: 'PUT',
        data : {pscu: pscu, psnew: psnew, psconfirm: psconfirm}
    })
    .then(function(data){
        console.log(131,data);
        alert(data.mess)
        $('.clo').trigger('click')
    })
    .catch(function(err){
        console.log(135,err);
        alert(err.mess)
    })
}