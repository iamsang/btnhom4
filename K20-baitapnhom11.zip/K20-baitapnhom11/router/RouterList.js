const express = require('express')
const router = express.Router()
const ListModel = require('../models/ListModel')
const TodoModel = require('../models/TodoModel')
const checkUser = require('../checkLogin')

const cookieParser = require('cookie-parser') // b1

router.use(cookieParser()) 


router.post('/', checkLogin,  async function(req,res){
    try {
      const checkList = await ListModel.findOne({userID: req.id, listName: req.body.listName})
      if(!checkList){
        await ListModel.create({userID: req.id, listName: req.body.listName})
        const listData = await ListModel.find({userID: req.id})
        res.status(200).render('pages/listPage/listData', {listData})
      }else{
        res.status(400).json({mess: 'list da co'})
      }
    } catch (error) {
      res.status(500).json({mess: 'loi server', error})
    }
  })
  
  router.delete('/:id', checkLogin, async function(req,res){
    try {
      await TodoModel.deleteMany({listID:req.params.id})
      await ListModel.deleteOne({_id:req.params.id})
      const listData = await ListModel.find({userID: req.id})
      res.status(200).render('pages/listPage/listData', {listData})
    } catch (error) {
      res.status(500).json({mess: 'loi server', error})
    }
  })
  
  router.get('/:id', async function(req,res){
    try {
      const listTodo = await TodoModel.find({listID: req.params.id})
      res.render('pages/todoPage/todo', {listTodo, status: ['todo', 'doing', 'done']})
      
    } catch (error) {
      res.status(500).json({mess: 'loi server', error})
    }
  })
  
  
  router.get('/page/:page/:status',checkLogin , async (req, res) =>{
    try {
        const data =  await UserModel150.find({status: req.params.status})
        .sort('dealine')
        .skip(5 * (req.params.page - 1) )
        .limit(5)
        data.sort(function(a,b){
            return new Date(`${a.dealine}`) - new Date(`${b.dealine}`);
        })
        res.json(data)
    } catch (error) {
        res.json({mess: 'loi sever', error})
    }
  })



module.exports = router