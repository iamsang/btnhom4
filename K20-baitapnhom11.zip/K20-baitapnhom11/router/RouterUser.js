const express = require('express')
const router = express.Router()
const path = require("path")

const cookieParser = require('cookie-parser') // b1

const UserModel = require('../models/UserModel')
const ListModel = require('../models/ListModel')

const checkUser = require('../checkLogin')
// const bcrypt = require('bcrypt')
const multer = require('multer')
var jwt = require('jsonwebtoken');
const TodoModel = require('../models/TodoModel')

 

const storage = multer.diskStorage({ 
    destination: function (req, file, cb) { 
      cb(null, 'public/uploads/') 
    },
    filename: function (req, file, cb) { 
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9)
      console.log(20, path.extname(file.originalname)); 
      cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname)) 
    }
  })
const upload = multer({ storage: storage })


router.use(cookieParser())

router.get('/home', async (req, res) =>{
    res.render('page/home.ejs')
})
// dang ky user
router.post('/profile', upload.single('imgdk'), async function(req,res,next){
    console.log(1000, req.file); 
    console.log(1111, req.file.path); 
    console.log(2000, req.body); 
    try {
        const data = await UserModel.findOne({ username: req.body.username })
        if (data) {
            res.json({ mess : 'Username đã tồn tại' })
        }else{
            const newUs = await UserModel.create({
                username : req.body.username,
                password : req.body.password,
                avatar : req.file.path // link
            })
            res.json({mess: 'Đăng ký thành công', newUs})
        }
    } catch (error) {
        res.json({mess: 'Lỗi sever', error})
    }
})

router.post('/login', async (req, res) =>{
    try {
        const user = await UserModel.findOne({ username : req.body.username })
        if (user) {
            console.log(61,user._id); 
            const token = jwt.sign({id : user._id}, '123'); // 
            console.log(63, token); // token
            UserModel.updateOne({_id: user._id}, {token: token})
            .then(function(data){
                res.cookie('user', token, {expires: new Date( Date.now() + 7*24*60*60*1000 )}) // set thời gian lưu id cookie 7 ngày
                res.json({user, mess:'Đăng nhập thành công'})
            })
        }else{
            res.json({mess:'user ko ton tai'})
        }
    } catch (error) {
        res.json({error ,mess:'loi sever'});
    }
})

router.put('/logout', function(req,res){
    let token = req.cookies.user
    UserModel.updateOne({token: token},
         {token: ''}
    )
    .then(function(data){
        res.json({mess: 'Logout OK'})
    })
    .catch(function(err){
        console.log(err);
    })
})
// page List
router.get('/list',checkUser, async (req, res) =>{ 
    try {
        console.log(91, req.cookies.user);
        const User = await UserModel.findOne({token: req.cookies.user})
        const ListData = await ListModel.find({userID: User._id})
        res.render('page/list', {user : User, listdata: ListData})
    } catch (error) {
        console.log(error); 
    }
})

router.post("/createList",checkUser, async function(req, res){ // api post
    try {
        const test = await ListModel.findOne({userID : req.id, ListName: req.body.ListName })
        if (test) {
            res.json({ mess : 'List đã tồn tại' })
        }else{
             await ListModel.create({
                ListName : req.body.ListName,
                userID : req.id,
            })
            const ListData = await ListModel.find({userID: req.id})
            res.render('components/userlist', {listdata: ListData})       
        }
    } catch (error) {
        res.json({error, mess : 'Lỗi Sever' })
    }
});

router.delete('/delList/:id',checkUser, async (req, res) =>{
    try {
        // await TodoModel.deleteMany({listID: req.params.id})
        await ListModel.deleteOne({_id: req.params.id})
        const ListData = await ListModel.find({userID: req.id})
        res.render('components/userlist', {listdata: ListData})
    } catch (error) {
        res.json({error ,mess:'loi sever'});
    }
})

router.put('/upList/:id',checkUser, async (req, res) =>{
    try {
        // console.log(153,req.body.ListName);
        const check = await ListModel.findOne( {ListName: req.body.ListName}  )
        if (check) {
            res.json({mess:'ListName đã tồn tại !'});
        } else {
            const data = await ListModel.updateOne({_id: req.params.id},
                {ListName: req.body.ListName}  )
            const ListData = await ListModel.find({userID: req.id})
            res.render('components/userlist', {listdata: ListData})
        }
    } catch (error) {
        res.json({error ,mess:'loi sever'});
    }
})

router.get('/change/:id', async (req, res) =>{
    try {
        const User = await UserModel.findOne({_id: req.params.id})
        res.render('page/change', {user: User})
    } catch (error) {
        console.log(error);
    }
})

router.put('/changePassword',checkUser, upload.single('imgchange'), async function(req,res,next){ 
    console.log(160, req.body); 
    try {
        const data = await UserModel.findOne({_id: req.id})
        if(data){
            if (data.password === req.body.pscu) { // kiểm tra mk cũ
                if (req.body.psnew === req.body.psconfirm) { // kiểm tra mk lặp lại
                    const newUser = await UserModel.updateOne({_id: req.id}, 
                        { password: req.body.psnew })
                    const datanew = await UserModel.findOne({_id: req.id})
                    res.json({datanew, mess:'Thay đổi mật khẩu thành công'})
                }else{
                    res.json({ mess:'mật khẩu mới nhập lại không đúng'})
                }
            } else {
                res.json({ mess:'mật khẩu cũ không đúng'})
            }
        }else{
            res.json({mess:'User ko tồn tại'})
        }
    } catch (error) {
        res.json({error ,mess:'loi sever'});
    }
})


router.put('/changeAvatar',checkUser, upload.single('imgchange'), async function(req,res,next){
    console.log(181, req.file); // để lấy file req.file 
    console.log(182, req.file.path); // 
    try {
        if (req.id) {
            const newAvatar = await UserModel.updateOne({_id: req.id}, 
                { avatar : req.file.path })
            const data = await UserModel.findOne({_id: req.id})
            res.json({mess: 'Thay đổi Avatar thành công', data})
        }else{
            res.json({ mess : 'Bạn chưa đăng nhập' })
        }
    } catch (error) {
        res.json({error ,mess:'loi sever'});
    }
})



module.exports = router