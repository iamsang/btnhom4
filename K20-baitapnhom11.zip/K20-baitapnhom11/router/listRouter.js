const router = require('express').Router()
const TodoModel = require('../models/TodoModel')
const checkUser = require('../checkLogin')


router.get('/:id',checkUser, async function(req,res){
  try {
    const listTodo = await TodoModel.find({listID: req.params.id})
    .sort('deadline')
    res.render('page/todo', {listTodo, status: ['todo', 'doing', 'done']})
    
  } catch (error) {
    res.status(500).json({mess: 'loi server', error})
  }
})


module.exports = router
