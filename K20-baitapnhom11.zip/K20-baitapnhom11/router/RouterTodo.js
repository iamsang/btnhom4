const express = require('express')
const router = express.Router()

const cookieParser = require('cookie-parser') // b1

router.use(cookieParser()) 

router.get('/home', function(req,res){
    // res.render('page/home.ejs')
    console.log(999);
})



module.exports = router