const router = require('express').Router()
const TodoModel = require('../models/TodoModel')
const checkUser = require('../checkLogin')

router.get('/', function(req,res){
  TodoModel.find()
  .then(function(data){
    res.json({data})
  })
  .catch(function(err){
    res.json({mess:'that bai', err})
  })
})

router.post('/', checkUser ,async function(req,res){
  try {
    let arr = req.headers.referer.split('/')
    let length = arr.length
    console.log(19);
    const n = await TodoModel.findOne({name:req.body.name})
    if(!n){
      await TodoModel.create({
        userID: req.id ,
        listID: arr[length-1],
        status: req.body.status,
        name: req.body.name,
        deadline: req.body.deadline
      })
      res.json({status: 200, mess:'ok'})
    }else{
      res.json({ mess:'name đã tồn tại'})
    } 
  } catch (error) {
    res.status(500).json({error})
  }
})

router.delete('/:id',checkUser, async function(req,res){
  try {
    await TodoModel.deleteOne({_id:req.params.id})
    res.status(200).json({mess: 'xóa thành công'})
  } catch (error) {
    res.status(500).json({mess: 'loi server', error})
  }
})

router.put('/:id',checkUser, async function(req,res){
    try {
      await TodoModel.updateOne({_id:req.params.id}
      ,{ status: req.body.status,
        name: req.body.name,
        deadline: req.body.deadline })
      res.json({status: 200, mess:'ok'})
    } catch (error) {
      res.status(500).json({error})
    }
  })

router.get('/:id',checkUser, async function(req,res){
  try {
  const todotest= await TodoModel.findOne({_id:req.params.id})
    res.json({todotest})
  } catch (error) {
    res.status(500).json({mess: 'loi server', error})
  }
})

router.get('/:id',checkUser, async function(req,res){
  try {
  const todotest= await TodoModel.findOne({_id:req.params.id})
    res.json({todotest})
  } catch (error) {
    res.status(500).json({mess: 'loi server', error})
  }
})


router.get('/:status/:page',checkUser, async (req, res) =>{
    try {
        const data =  await TodoModel.find({status: req.params.status})
        .sort('deadline')
        // .skip(2 * (req.params.page - 1) )
        // .limit(2)
        // $('.todo').html(data)
        // res.render('page/todo', {listTodo, status: ['todo', 'doing', 'done']})
        res.json(data)
    } catch (error) {
        res.json({mess: 'loi sever', error})
    }
})
// giới hạn xem 




module.exports = router