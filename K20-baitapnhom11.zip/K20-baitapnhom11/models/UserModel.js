const mongoose = require('mongoose'); 
mongoose.connect('mongodb://localhost/K20') 

const UserSchema = mongoose.Schema({ 
  "username" : String,
  "password" : String,
  avatar: String,
  token: String
},{ collection: 'K20-User' })

const UserModel = mongoose.model('K20-User', UserSchema)   

module.exports = UserModel