const mongoose = require('mongoose'); 
mongoose.connect('mongodb://localhost/K20') 

const ListSchema = mongoose.Schema({ 
  ListName : String,
  userID : {
    type: String, 
    ref: 'K20-User' 
  }
},{ collection: 'K20-List' })

const TodoModel = mongoose.model('K20-List', ListSchema)   

module.exports = TodoModel

