const mongoose = require('mongoose'); 
mongoose.connect('mongodb://localhost/K20') 

const TodoSchema = mongoose.Schema({ 
  "name" : String,
  "deadline" : String,
  status : String,
  userID : {
    type: String, 
    ref: 'K20-User' 
  },
  listID:{
    type: String, 
    ref: 'K20-List' 
  }
},{ collection: 'K20-Todo' })

const TodoModel = mongoose.model('K20-Todo', TodoSchema)   

module.exports = TodoModel

